from endstone.command import CommandSender
from endstone import Player, ColorFormat
from endstone.level import Location
from pathlib import Path
import yaml


def execute(sender: CommandSender, args: list[str], plugin) -> bool:
    if not isinstance(sender, Player):
        sender.send_message(f"{ColorFormat.RED}Solo los jugadores pueden usar este comando")
        return False

    try:
        config_path = Path(plugin.data_folder) / "config.yml"
        with open(config_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f)

        spawn_data = config.get("spawn", {}).get("location")

        if not spawn_data:
            sender.send_message(f"{ColorFormat.RED}El spawn no ha sido establecido")
            return False

        x = spawn_data.get("x")
        y = spawn_data.get("y")
        z = spawn_data.get("z")
        dimension_id = spawn_data.get("dimension", "minecraft:overworld")

        level = plugin.server.level
        dimension = level.get_dimension(dimension_id)
        spawn_location = Location(dimension, x, y, z)

        sender.teleport(spawn_location)
        sender.send_message(f"{ColorFormat.GREEN}¡Te has teletransportado al spawn!")
        plugin.logger.info(f"{sender.name} se teletransportó al spawn")

    except Exception as e:
        sender.send_message(f"{ColorFormat.RED}Error al teleportarse al spawn: {str(e)}")
        plugin.logger.error(f"Error en spawn_command: {str(e)}")
        return False

    return True