from endstone.command import CommandSender
from endstone import Player, ColorFormat
from pathlib import Path
import yaml


def execute(sender: CommandSender, args: list[str], plugin) -> bool:
    if not isinstance(sender, Player):
        sender.send_message(f"{ColorFormat.RED}Solo los jugadores pueden usar este comando")
        return False

    try:
        location = sender.location
        spawn_location = {
            "x": round(location.x, 2),
            "y": round(location.y, 2),
            "z": round(location.z, 2),
            "dimension": str(location.dimension.name)
        }

        config_path = Path(plugin.data_folder) / "config.yml"
        with open(config_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}

        if "spawn" not in config:
            config["spawn"] = {}

        config["spawn"]["location"] = spawn_location

        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(config, f, default_flow_style=False, allow_unicode=True)

        sender.send_message(f"{ColorFormat.GREEN}✓ Spawn establecido en {spawn_location}")
        plugin.logger.info(f"Spawn establecido por {sender.name} en {spawn_location}")

    except Exception as e:
        sender.send_message(f"{ColorFormat.RED}Error al establecer spawn: {str(e)}")
        plugin.logger.error(f"Error en setspawn_command: {str(e)}")
        return False

    return True